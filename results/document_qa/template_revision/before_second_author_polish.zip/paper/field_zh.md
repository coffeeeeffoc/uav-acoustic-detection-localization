# 基于方向条件相干谱排序的小型无人机声学探测与测向

Ju Luo

南京航空航天大学

南京，中国

## 摘要

相干背景声源可能主导声学空间图并掩盖无人机方向。本文提出方向条件相干谱排序（DCCR），以24个相干频带特征和类别平衡岭回归对四个导向响应功率候选评分。208通道阵列室外录音按位置划分：100 m用于开发，150–200 m用于保留评价。在600个无人机观测窗上，相对于标称方向的平均偏差由相位变换基线的14.78°降至6.97°；检出率为85.7%，200个背景窗上的虚警率为1.5%。共用检测门控时，检出且定位偏差不超过10°的比例由76.5%升至85.5%。改善主要体现为大角度错误减少。证据仍限于单一机型、单日采集、标称静态参考、相关观测窗及本地背景标定。

**关键词** — 无人机声学，麦克风阵列，到达方向，空间相干性，候选方向排序。

## I 引言

被动声学感知需要在风、车辆及机械噪声中检出无人机辐射声并确定其方向[1]。广义互相关与导向响应功率（steered response power，SRP）汇总麦克风间时延证据[2]、[3]。相位变换（phase transform，PHAT）强调相位一致性，相干非目标声源也可能主导空间响应。已有SRP扩展改善了频谱可靠性与空间搜索[4]，但对整幅空间图施加相同检测分数不能改变其最大值方向。

DCCR利用方向相干谱对四个SRP-PHAT候选排序。训练包含来自同一无人机观测的竞争方向，其背景和整体增益相同。本文贡献在于以既有阵列运算实现候选方向条件下的声源关联，并通过共用检测器的比较区分方向选择与报警决策的影响。

## II 相关研究

噪声相关波束形成与跟踪[5]、部分PHAT加权[6]及相干噪声中的辅助麦克风SRP[7]均着重改善空间可靠性。无人机专用方法利用旋翼谐波[8]，或结合合成信号与神经网络定位[9]。DCCR采用固定频带和紧凑线性模型，本文未与上述训练后的神经网络系统直接比较。DDL[10]和UaVirBASE[11]提供多通道无人机数据，强调采集几何及参考测量记录。现有录音支持标称静态方向比较，但缺乏用于跟踪评价的同步轨迹。

## III 信号模型与方向特征

### A 阵列与频谱估计

设麦克风位置为r_m，远场单位方向为u，则

$$ x_m(t)=a_m s(t+\mathbf{r}_m^{T}\mathbf{u}/c)+v_m(t). $$ (1)

其中a_m为通道增益，v_m包含背景与传感器噪声，声速c = 343 m/s。阵列孔径0.30 m远小于100–200 m标称距离。为消除平面阵列的镜像歧义，搜索限定于上半球。方位角a从原生负y方向顺时针计量，俯仰角e相对于阵列平面定义：

$$ \mathbf{u}(a,e)=(-\cos e\sin a,-\cos e\cos a,\sin e)^{T}. $$ (2)

每个200 ms观测窗按通道去均值，并通过抗混叠多相滤波由48 kHz重采样至16 kHz。512点周期Hann窗、256点帧移产生L = 11个去均值傅里叶帧，分析范围为300–7500 Hz。设X_m(l,k)为第l帧、第k频点的频谱，则平均互谱与自谱为

$$ R_{ij}(k)=L^{-1}\sum_{l=1}^{L}X_i(l,k)X_j(l,k)^{*},\qquad P_i(k)=R_{ii}(k). $$ (3)

相干归一化谱与PHAT谱分别为

$$ C_{ij}(k)=\frac{R_{ij}(k)}{\max(\sqrt{P_i(k)P_j(k)},\epsilon)},\qquad Q_{ij}(k)=\frac{R_{ij}(k)}{\max(|R_{ij}(k)|,\epsilon)}. $$ (4)

数值下限为带内平均通道功率的10⁻¹²倍，且不低于10⁻³⁰。先平均后归一化，避免单帧相干幅值恒为1。所有方法共用覆盖208通道的1124个通道对：按模208的索引偏移17、35、53、71、89和103构造，去重并保留基线不小于0.06 m的通道对。

### B 候选方向与相干特征

对于通道对集合P和频率集合F，PHAT评分为

$$ B(\mathbf{u})=\sum_{(i,j)\in\mathcal{P}}\sum_{k\in\mathcal{F}}\operatorname{Re}\{Q_{ij}(k)e^{-j2\pi f_k(\mathbf{r}_i-\mathbf{r}_j)^{T}\mathbf{u}/c}\}. $$ (5)

水平方向余弦网格包含1257点、间隔0.05，保留两两至少相隔12°的四个峰值。各候选在±0.05邻域内以0.005间隔细化，再于方位角±1°、俯仰角±2°内以0.1°间隔细化。该步长不代表物理精度。实现采用八倍插值逆FFT相关表及线性时延查表。

将300–7500 Hz划分为24个相邻300 Hz频带，并包含末端频点。方向u的特征为

$$ f_b(\mathbf{u})=\frac{1}{|\mathcal{P}|\,|\mathcal{F}_b|}\sum_{(i,j)\in\mathcal{P}}\sum_{k\in\mathcal{F}_b}\operatorname{Re}\{C_{ij}(k)e^{-j2\pi f_k(\mathbf{r}_i-\mathbf{r}_j)^{T}\mathbf{u}/c}\}. $$ (6)

这些有符号特征保留随频率变化的方向支持程度。未触及数值下限时，正增益在归一化中抵消。回归模型仅接收24个频带值，不使用绝对功率、方向坐标、录音标识、距离或视频。图1给出了阵列几何和拟合系数。

## IV 模型学习与联合推理

### A 开发样本与正则化

P1包含300个无人机窗及100个背景窗。参考导向波束和偏差不超过5°的候选为正例；偏差至少15°的候选及背景候选为负例；中间区域候选排除。参考波束仅用于训练。1779个样本包括598个正例和1181个负例，后者含781个来自无人机观测的错误方向。

两个分组折各保留一整段无人机录音及开发背景中连续10 s的一半，同一观测窗的样本保持在同一折。这不构成跨独立背景录音的泛化检验。特征均值与标准差在训练折内按类别平衡权重估计，标准差下限为0.01。对标准化特征z_n和标签y_n ∈ {−1,+1}，最小化

$$ \sum_{n=1}^{N}w_n(\boldsymbol{\beta}^{T}\mathbf{z}_n+b-y_n)^2+\lambda\|\boldsymbol{\beta}\|_2^2. $$ (7)

各类别权重之和为N/2，截距不正则化。平衡验证平方误差从{0.1，1，10，100}中选择λ = 100，再以全部开发样本拟合。消融模型仅去除781个错误方向负例，按相同分折独立选定λ = 10，其余推理过程不变。

![图1 阵列几何及标准化相干频带的拟合系数，模型仅使用开发数据学习。](../figures/field/geometry_weights_zh.png)

### B 方向选择与标定

对四个由音频产生的候选，计算

$$ s_q=\boldsymbol{\beta}^{T}[(\mathbf{f}(\mathbf{u}_q)-\boldsymbol{\mu})/\boldsymbol{\sigma}]+b,\qquad q^{*}=\operatorname{argmax}_{q}s_q. $$ (8)

所选方向和检测分数为u_q*及s_q*。该分数为回归输出而非后验概率。各方法使用每个测试组内相同的25个独立划分背景窗标定。标称上尾水平为0.05时，顺序统计量秩ceil(26 × 0.95)为25；评分须严格大于标定最大值才判为检出。时间相关与非平稳性使其不具有正式5%虚警保证。所有无人机窗均估计方向，包括漏检窗；联合成功另要求检出且偏差≤10°。

## V 实测实验

### A 录音与评价划分

2026年5月25日，朝向上方的CRY8501/SonoCam Pi阵列采集DJI Air 3S录音[12]。三个位置各含两段无人机录音和一段背景录音（表I），每段208通道、48 kHz、16位PCM。九段录音总计273.75 s。1872个WAV文件通道长度一致，未达到PCM削波边界，但这不独立证明相位或时钟标定准确。标称方向来自采集示意图，缺乏用于量化悬停位移及参考不确定性的同步轨迹。视频既不输入估计器，也不替代真值。

**表I 录音分组及标称方向，各组含两段无人机录音和一段背景录音。**

| 分组 | 标称距离 | 录音1／录音2方位角 | 俯仰角 | 用途 |
|---|---|---|---|---|
| P1 | 100 m | 225.00° / 251.50° | 88.3° | 方法开发 |
| P2 | 150 m | 97.17° / 92.41° | 60.0° | 保留评价 |
| P3 | 200 m | 131.88° / 135.00° | 66.4° | 保留评价 |

每段无人机录音使用前30 s；背景的[0,5)、[5,10)和[10,30) s分别用于谱扣除参考、阈值标定和负例评价。P2/P3提供600个无人机窗及200个背景窗，另有50个标定窗。P1仅用于开发。本地背景标定是明确的运行前提。

### B 比较方法与指标

基线共用几何、通道对、频带和搜索过程：SRP-PHAT；使用C_ij的平滑相干变换（smoothed coherence transform，SCOT）SRP；以及以Q_ij clip((L|C_ij|²−1)/(L−1),0,1)加权的相干PHAT。最后一项为有限快拍启发式，在重叠帧下不是无偏估计。背景扣除基线按当前与参考功率比缩放背景谱，扣除互谱，再由残余相干性及超额功率可靠性加权残余相位。复现代码给出完整运算，该基线并非文献[5]的复现。

分别使用各方法自己的标定检测器及固定的完整DCCR检测器进行比较。候选理想选择仅在推理结束后使用参考标签计算。估计与标称参考单位向量的角偏差为

$$ e_{\mathrm{ang}}=\frac{180}{\pi}\arccos[\operatorname{clip}(\widehat{\mathbf{u}}^{T}\mathbf{u}_{\mathrm{ref}},-1,1)]. $$ (9)

定位统计包含全部600个无人机窗；检出率及虚警率分别使用无人机和背景窗。800个观测窗存在时间相关性，不能视为独立试验，故采用描述性统计并列出四段录音的配对差值。代码、模型和输入哈希在保留评价前冻结。计时环境为Intel Core i7-12700KF、Python 3.12.14、NumPy 2.2.6和SciPy 1.15.3，数值库请求单线程；计时包含共用前端开销、排除文件读取，非隔离基准测试。

## VI 结果

### A 定位结果

DCCR平均偏差由SRP-PHAT的14.78°降至6.97°，配对差值为+7.82°；中位数为3.47°，95百分位为54.16°，10°以内比例为94.0%（表II）。

**表II 全部600个保留无人机窗相对于标称方向的偏差，包含漏检窗。**

| 方法 | 均值 ° | 中位数 ° | 95百分位 ° | ≤5° % | ≤10° % |
| --- | --- | --- | --- | --- | --- |
| SRP-PHAT | 14.78 | 3.49 | 96.87 | 84.8 | 84.8 |
| SCOT-SRP | 15.35 | 3.46 | 96.87 | 84.0 | 84.0 |
| 相干性加权PHAT | 18.46 | 3.43 | 95.78 | 80.0 | 80.0 |
| 背景互谱扣除 | 12.19 | 3.51 | 71.83 | 87.2 | 87.2 |
| DCCR无困难负例 | 6.97 | 3.47 | 54.16 | 94.0 | 94.0 |
| DCCR | 6.97 | 3.47 | 54.16 | 94.0 | 94.0 |

四段录音均改善，配对差值为+0.68°至+14.76°（表III）。候选理想选择的均值为6.44°，10°以内比例为94.3%；该事后参考辅助诊断仅描述候选覆盖，不是可实现的推理成绩。

**表III 各录音平均偏差。PHAT减DCCR的正差值表示改善，差值在四舍五入前计算。**

| 录音 | SRP-PHAT ° | DCCR ° | 差值 ° |
| --- | --- | --- | --- |
| P2 take 1 | 6.95 | 4.28 | +2.67 |
| P2 take 2 | 3.23 | 2.55 | +0.68 |
| P3 take 1 | 17.32 | 4.16 | +13.16 |
| P3 take 2 | 31.62 | 16.87 | +14.76 |

图2汇总角偏差分布及检测工作点。

![图2 保留数据的角偏差分布及独立标定后的检测结果。角度在1°以上采用对数尺度；DCCR与消融模型的分布近乎重合。](../figures/field/performance_zh.png)

### B 检测与消融

DCCR检出514/600窗（85.7%），虚警3/200窗（1.5%），见表IV。P2/P3检出率分别为83.0%/88.3%，虚警率为0.0%/3.0%；标称5%标定水平不等于实际虚警率。

**表IV 各方法独立标定后的检测与联合结果，检出率及虚警率分母分别为600个无人机窗和200个背景窗。**

| 方法 | 检出数 | 虚警数 | 检出率 % | 虚警率 % | 联合成功 % |
| --- | --- | --- | --- | --- | --- |
| SRP-PHAT | 148 | 1 | 24.7 | 0.5 | 19.2 |
| SCOT-SRP | 61 | 1 | 10.2 | 0.5 | 5.0 |
| 相干性加权PHAT | 39 | 1 | 6.5 | 0.5 | 1.0 |
| 背景互谱扣除 | 41 | 1 | 6.8 | 0.5 | 0.2 |
| DCCR无困难负例 | 473 | 3 | 78.8 | 1.5 | 78.8 |
| DCCR | 514 | 3 | 85.7 | 1.5 | 85.5 |

固定DCCR检测门控后，联合成功率由PHAT方向的76.5%升至DCCR的85.5%。两者使用相同的514个检出窗，9.0个百分点的差别来自方向选择。

去除困难负例后，均值仍为6.97°，检出率为78.8%，虚警率为1.5%。完整模型在相同虚警数下多检出41窗；仅3个正窗选向不同，且偏差均超过10°。因此该消融支持当前工作点的检测收益，未显示额外定位增益。

DCCR每窗计算时间中位数/95百分位为414.9/588.7 ms，PHAT为227.9/331.3 ms，另需200 ms采集窗。四候选细化及特征计算增加开销；当前串行实现不能维持每秒5窗，未实现实时运行。

图3比较相同观测窗，两种估计器均未采用平滑或跟踪。

![图3 四段保留无人机录音的逐窗偏差，角度轴在1°以上采用对数尺度。](../figures/field/recordings_zh.png)

## VII 讨论

均值改善主要源于大偏差减少，而非所有估计均更精细：中位数由3.49°变为3.47°，95百分位仍为54.16°。36个超过10°的DCCR偏差中，34个没有10°以内候选，33个出现在P3录音2。候选覆盖因而限制了剩余尾部表现；排序器无法恢复候选集中不存在的方向。

较早的背景谱不能重建变化中的车辆或风声，这可解释直接扣除收益有限。DCCR避免该扣除，但仍受机型、传播及传感器变化影响。证据来自单机型、单日及具有本地标定的六段保留录音，不是800次独立现场试验。标称静态参考无法分离悬停运动、朝向误差和相位失配；负例也未穷尽易混淆机械声和同时声源。距离、身份、多无人机分离及跟踪不在评价范围内。改进候选覆盖并引入同步参考需新的开发和保留数据。

## VIII 结论

DCCR通过24频带相干特征对四个方向排序，使保留录音平均标称方向偏差由14.78°降至6.97°，共用门控联合成功率由76.5%升至85.5%。收益主要来自大角度错误减少；困难负例仅显示检测改善。进一步验证需覆盖更多机型、采集时段和同步参考轨迹。

## 数据与代码可用性

随文资料包含代码、拟合模型、开发记录、输入哈希、逐窗预测及绘图脚本。原始录音的访问和分发遵循其提供方条件。

## 参考文献

[1] P. Chen, Y. Chen, and W. Wang, "Review for UAV Acoustic Positioning," Journal of South China University of Technology (Natural Science Edition), vol. 50, no. 12, pp. 109–123 (in Chinese), 2022. [doi: 10.12141/j.issn.1000-565X.220277](https://doi.org/10.12141/j.issn.1000-565X.220277).

[2] C. H. Knapp and G. C. Carter, "The generalized correlation method for estimation of time delay," IEEE Transactions on Acoustics, Speech, and Signal Processing, vol. 24, no. 4, pp. 320–327, 1976. [doi: 10.1109/TASSP.1976.1162830](https://doi.org/10.1109/TASSP.1976.1162830).

[3] J. H. DiBiase, H. F. Silverman, and M. S. Brandstein, "Robust Localization in Reverberant Rooms," in Microphone Arrays: Signal Processing Techniques and Applications, M. Brandstein and D. Ward, Eds. Berlin, Germany: Springer, ch. 8, pp. 157–180, 2001. [doi: 10.1007/978-3-662-04619-7_8](https://doi.org/10.1007/978-3-662-04619-7_8).

[4] E. Grinstein et al., "Steered Response Power for Sound Source Localization: a tutorial review," EURASIP Journal on Audio, Speech, and Music Processing, vol. 2024, Art. no. 59, 2024. [doi: 10.1186/s13636-024-00377-z](https://doi.org/10.1186/s13636-024-00377-z).

[5] J.-M. Valin, F. Michaud, and J. Rouat, "Robust localization and tracking of simultaneous moving sound sources using beamforming and particle filtering," Robotics and Autonomous Systems, vol. 55, no. 3, pp. 216–228, 2007. [doi: 10.1016/j.robot.2006.08.004](https://doi.org/10.1016/j.robot.2006.08.004).

[6] K. D. Donohue, J. Hannemann, and H. G. Dietz, "Performance of phase transform for detecting sound sources with microphone arrays in reverberant and noisy environments," Signal Processing, vol. 87, no. 7, pp. 1677–1691, 2007. [doi: 10.1016/j.sigpro.2007.01.013](https://doi.org/10.1016/j.sigpro.2007.01.013).

[7] K. Brümann and S. Doclo, "Steered Response Power-Based Direction-of-Arrival Estimation Exploiting an Auxiliary Microphone," in Proc. 32nd European Signal Processing Conference (EUSIPCO), pp. 917–921, 2024. [doi: 10.23919/EUSIPCO63174.2024.10715232](https://doi.org/10.23919/EUSIPCO63174.2024.10715232).

[8] S. Uluskan, "Precise acoustic drone localization and tracking via drone noise: Steered response power - phase transform around harmonics," International Journal of Aeroacoustics, vol. 23, nos. 5–6, pp. 558–577, 2024. [doi: 10.1177/1475472X241259082](https://doi.org/10.1177/1475472X241259082).

[9] X. Yang, P. A. Naylor, S. Doclo, and J. Bitzer, "Neural Drone Localization Exploiting Signal Synthesis of Real-World Audio Data," in Proc. 33rd European Signal Processing Conference (EUSIPCO), pp. 256–260, 2025. [doi: 10.23919/EUSIPCO63237.2025.11226465](https://doi.org/10.23919/EUSIPCO63237.2025.11226465).

[10] S. Safavi, Ö. Çaylı, M. A. Safavi, B. Cook, and W. Wang, "DDL: A Dataset for Drone Detection and Localization From Multi-Channel Audio and a Deep Uncertainty-Aware Framework," in Proc. IEEE 35th International Workshop on Machine Learning for Signal Processing (MLSP), pp. 1–6, 2025. [doi: 10.1109/MLSP62443.2025.11204285](https://doi.org/10.1109/MLSP62443.2025.11204285).

[11] G. Jekateryńczuk, R. Szadkowski, and Z. Piotrowski, "UaVirBASE: A Public-Access Unmanned Aerial Vehicle Sound Source Localization Dataset," Applied Sciences, vol. 15, no. 10, Art. no. 5378, 2025. [doi: 10.3390/app15105378](https://doi.org/10.3390/app15105378).

[12] "Experimental measurement description," acquisition documentation accompanying the CRY8501 Air 3S recordings of 25 May 2026, unpublished technical dataset, 2026 (in Chinese).
