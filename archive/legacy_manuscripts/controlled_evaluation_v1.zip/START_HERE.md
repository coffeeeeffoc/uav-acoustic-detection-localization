# 论文与复现资料入口

英文论文以谐波与相干加权的受控比较为主题，中文稿为完整译稿。论文采用独立学术叙述，原始方向材料不构成实验条件或性能门槛。

## 阅读论文

- [英文 PDF，8 页](paper/manuscript_en.pdf) · [英文可编辑稿](paper/manuscript_en.md)
- [中文 PDF，10 页](paper/manuscript_zh.pdf) · [中文可编辑稿](paper/manuscript_zh.md)
- 两稿包含相同的 16 个公式、6 张表、3 幅图及 19 条参考文献。英文为通用 IEEE 式双栏排版，中文采用便于阅读的单栏排版；不是某一会议的正式模板。

## 数据和结论

定量结果来自真实执行的仿真程序：800 个验证负样本、2000 个静态测试样本、120 组四条件敏感性实验和 24 条连续序列，共保存 3304 份八通道 NPZ 录音，覆盖 6160 个音频帧。另保存一段具有 CC BY 4.0 许可的 IDMT 实测录音，仅作声谱展示，没有将其作为实测检测或定位验证。

结果属于消融与失效分析：组合加权总体平均角误差为 26.55°，基线 PHAT 为 24.84°；共享检测器召回率 3.50%、虚警率 5.60%；门控跟踪覆盖率仅 5.625%。论文没有把条件性收益、平滑外观或工作站计算速度表述成可靠的完整无人机探测系统。

| 内容 | 路径 |
|---|---|
| 文献调研与数据集辨析 | [research/literature_review.md](research/literature_review.md) |
| 已核验参考文献、BibTeX、原文与来源记录 | [references/references.json](references/references.json)、[references/references.bib](references/references.bib)、`references/papers/` |
| 完整仿真数据 | `data/synthetic/full/` |
| 公开录音、原始标签与授权溯源 | `data/public/idmt_sample/` |
| 原始逐帧输出、冻结参数、环境和哈希 | `results/full/` |
| 全量方法与结果说明 | [results/method_and_results.md](results/method_and_results.md) |
| 独立方法审查 | [results/independent_method_review.md](results/independent_method_review.md) |
| 全数据复现核查 | [results/full/verification.json](results/full/verification.json) |
| 正文、双语表格与 PDF 检查 | [results/document_qa/delivery_verification.json](results/document_qa/delivery_verification.json) |
| 论文图及补充图 | `figures/`、`figures/full/` |
| 实验代码说明 | [code/EXPERIMENT_README.md](code/EXPERIMENT_README.md) |

`results/quick/` 是早期工程检查，源码版本不同于完整实验，不作为论文证据。`results/full/config.json` 冻结的实验源码哈希与当前 `code/experiment.py` 一致。独立审查发现的单有效单位 bootstrap 问题已修正：少于两个有效单位时区间记为 null；完整实验数值不受该修正影响。四种方法共用同一检测器，研究问题和结论均按定位消融及共享检测器评价表述。

## 本机复现

在本目录的 PowerShell 中执行。Python 为本机已有的 3.12.14，数值库位于 `.python-packages/`；没有调用外部排版服务。

```powershell
$paperPython = 'C:\Users\15211\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $paperPython code/verify_experiment.py
& $paperPython code/verify_delivery.py
```

重建分析图表和论文，不重新生成音频：

```powershell
& $paperPython code/summarize_experiment.py results/full
& $paperPython code/inspect_public_audio.py
& $paperPython code/build_papers.py --assets
& $paperPython code/build_papers.py
& $paperPython code/verify_experiment.py
& $paperPython code/verify_delivery.py --render
```

若要从头运行声学实验，使用 `code/experiment.py --full`。程序会拒绝覆盖已完成的输出；应在独立副本中运行或先妥善归档原来的 `results/full/`，保留现有证据。种子、参数和数据路径均已记录。重复实验的声学结果可复现，实际耗时会受机器负载影响。

其他机器使用 Python 3.12，先安装 `code/requirements-lock.txt` 与 `code/paper-requirements.txt`。排版脚本当前读取 Windows 的 Times New Roman 和宋体；跨平台时需要提供相应字体文件并修改字体路径。PDF 公式为 300 dpi 图像，正文可选取和搜索，Markdown 保留可编辑公式源码。

## 投稿前事项

原始 `README.md` 和方向参考文件原样保留。正文没有作者及单位信息，需投稿时补充并套用目标刊会模板。尚未取得 iThenticate 或其他正式相似度报告，不能声明已满足总重复率或单篇来源比例要求。实测有效距离、真实机型分类与现场系统性能均未验证；这些属于后续外部验证，而非本论文已经完成的结论。
