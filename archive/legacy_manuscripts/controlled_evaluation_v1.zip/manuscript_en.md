# A Controlled Evaluation of Harmonic and Coherence Weighting for Acoustic UAV Detection and Localization

## Abstract

Passive acoustic sensing of low-altitude small unmanned aerial vehicles requires both reliable target decisions and stable direction estimates. This paper presents a reproducible simulation study of an eight-microphone pipeline combining spectral harmonic evidence, magnitude-squared coherence, steered response power with phase transformation (SRP-PHAT), and causal direction smoothing. Standard PHAT, coherence weighting, harmonic weighting and their combination are compared on identical observations. The evaluation uses 800 target-absent validation frames, 2000 independent static test frames, 120 paired sensor-perturbation cases and 24 continuous sequences. Across 1000 target-present static trials, combined weighting gives a mean spherical error of 26.55 degrees, compared with 24.84 degrees for PHAT. It improves the directional-broadband subgroup by 2.70 degrees but worsens the engine-like subgroup by 9.51 degrees. At a threshold calibrated for approximately 5% false alarms, the shared detector obtains 3.50% recall and 5.60% false alarms, exposing the failure of tonal coherence as an aircraft identity cue. Causal smoothing reduces frame-to-frame movement but increases the combined method's mean tracking error by 1.37 degrees. These negative results delimit where apparently complementary acoustic cues cease to be useful. Complete generated audio, code and per-trial outputs support reproducibility. A real recording illustrates spectral characteristics; quantitative conclusions are restricted to the simulated conditions.

**Index terms:** unmanned aerial vehicle; microphone array; acoustic detection; direction of arrival; SRP-PHAT; harmonic analysis; reproducible simulation.

## I Introduction

Low-altitude, slow-moving, small unmanned aerial vehicles (UAVs) motivate passive sensing that can complement optical, radio-frequency and radar observations. A ground microphone array can exploit motor and rotor sound without requiring the target to transmit a cooperative signal. However, the presence of a prominent acoustic source does not establish that it is a UAV, and an accurate bearing in one frame does not establish reliable continuous detection. Environmental machinery, wind, calibration errors and intermittent observations must therefore be considered together with localization error. Chen et al. identify time-delay estimation, beamforming and subspace methods as the principal acoustic localization families [1].

An important design question is whether spectral periodicity and spatial consistency provide complementary evidence under competing acoustic sources. Periodicity can concentrate processing on rotor-related frequency bands, while spatial consistency can suppress incoherent noise. Both properties, however, may also characterize a mechanical interferer. Their combination can therefore improve one interference condition and degrade another. A controlled study that preserves difficult negatives and separates detection from bearing estimation is needed to identify this trade-off. The present evaluation varies signal-to-noise ratio (SNR), nuisance type and sensor perturbations while retaining common observations across estimators.

Generalized cross-correlation with phase transformation (GCC-PHAT) and steered response power with PHAT weighting (SRP-PHAT) provide interpretable starting points [2, 3]. PHAT reduces the dominance of large spectral magnitudes, but also allows poorly supported frequency bins to contribute to a directional score. Coherence can reduce the contribution of inconsistent microphone pairs, while rotor-related harmonics can select potentially informative frequencies. Neither cue is sufficient on its own. A coherent interfering source may dominate a coherence-weighted map, and a harmonic non-UAV source may satisfy an acoustic periodicity detector. Their combination warrants evaluation against each component, including situations in which the combination fails.

The research question is therefore limited and testable: under a declared small-array simulation distribution, how do coherence and estimated harmonic weighting change direction estimation, and can a shared harmonic-coherence detector support a useful causal track? The detector is evaluated once, rather than treated as four independent detection ablations. Building on established weighted-SRP methods, this study contributes a controlled localization ablation, independent threshold calibration with nuisance-specific false-alarm analysis, and sequence-level evidence separating trajectory smoothness from tracking accuracy and availability. Individual outcomes and paired uncertainty estimates are retained throughout. These comparisons characterize the benefits and failure mechanisms of the selected combination under explicitly defined acoustic conditions.

## II Related Work

### A Correlation and spatial search

Knapp and Carter established the generalized correlation framework for time-delay estimation [2]. An array can combine pairwise delay evidence by evaluating the delays predicted by candidate directions. The SRP literature discusses this direct spatial search, its robustness and its computational trade-offs [3, 4]. MUSIC instead uses a signal/noise subspace decomposition and a frequency-dependent steering model [5]. These are different estimators with different assumptions. The experiments here retain an SRP implementation as the common backbone so that performance differences can be attributed to the selected weights. They are not a comprehensive ranking of SRP, MUSIC and neural approaches.

Frequency weighting, time-frequency masks, reliability estimates and reduced search strategies already have substantial prior art. The recent SRP tutorial organizes these developments and provides a modular implementation perspective [4]. Donohue et al. studied PHAT behavior in noisy and reverberant conditions [6], while Valin et al. combined robust beamforming with source tracking [7]. Brümann and Doclo studied SRP using an auxiliary microphone [8]. These approaches establish that spectral reliability and additional acoustic information are mature research directions. Accordingly, multiplying a PHAT spectrum by another weight is not by itself a sufficient novelty claim. The useful question is whether the selected information improves a declared task, and whether any gain survives calibration errors, difficult negative sounds and a fixed false-alarm operating point.

### B UAV sound and learning-based localization

Multirotor sound contains tonal components associated with periodic rotation together with broadband aerodynamic components. Their relative strengths and frequency trajectories depend on the aircraft and flight condition; a single fixed comb should not be treated as a universal aircraft fingerprint [1, 9]. Yang et al. investigated synthesis-informed neural localization and compared neural models with SRP-PHAT variants using both simulated and real UAV data [10]. Their work is especially relevant because it includes magnitude and frequency-mask modifications of SRP. The present paper does not claim that simulation-trained or masked localization is new, and its controlled simulation results cannot be compared numerically with their field results as if the datasets were identical.

Learning-based localization can exploit richer spectral and temporal structure, but requires appropriate training distributions, annotations and evaluation splits. Reviews of neural localization show the breadth of available formulations [11]. The compact study here avoids training a large model without a representative field corpus. This choice enables transparent ablations; it does not establish that a hand-designed pipeline is superior to learned alternatives. Similarly, harmonic evidence is treated as evidence for the simulated target class, not proof of UAV identity in an unrestricted acoustic environment.

Uluskan explicitly studied SRP-PHAT around drone harmonics for localization and tracking [12]. This is particularly close prior art: harmonic concentration is not a new principle introduced here. The present contribution is a specified harmonic-coherence combination evaluated through paired ablations and nuisance-dependent failure analysis. Recent multi-channel work also includes uncertainty-aware detection/localization and learned acoustic imaging [13, 14]. Their presence further limits any broad novelty or state-of-the-art claim for a compact analytic pipeline.

### C Data and validation boundaries

Public resources must be distinguished by sensor placement and annotation. UaVirBASE provides ground-array UAV localization recordings and metadata [15]. A Western Sydney University dataset describes a 24-channel ground-array recording setup with synchronized flight information [16]. Such data can support future external validation after channel order, array geometry, time alignment and coordinate conventions have been checked. A public landing page alone is not evidence that an experiment has used the recordings. The present numerical evaluation uses generated signals, with public datasets recorded as follow-on resources.

Airborne audition datasets answer a different question when microphones are attached to a UAV and the desired source is a person or another external sound. DREGON and DroneAudioset are relevant examples of the ego-noise problem [17, 18]. Treating their task labels as ground-array drone-bearing labels would be inappropriate. This distinction matters when collecting apparently relevant data by keyword alone.

## III Signal Model and Task Definition

Let the array contain M microphones at positions r_m, and let a source direction be represented by azimuth theta and elevation phi. The coordinate convention follows a right-handed horizontal plane: azimuth increases counterclockwise from the positive x axis, while elevation is measured upward from the plane. The upper hemisphere is used, consistent with a target above the ground array. Its unit direction vector is

$$\mathbf{u}(\theta,\phi)=[\cos\phi\cos\theta,\ \cos\phi\sin\theta,\ \sin\phi]^{T}.$$ (1)

An illustrative continuous-time observation model is

$$x_m(t)=a_m s(t-\tau_m)+v_m(t).$$ (2)

Here s is the target waveform, a_m is channel gain, tau_m is propagation delay and v_m contains sensor noise and interfering acoustic sources. Additional propagation and channel perturbations are specified in Section V. In far-field steering, the relative delay of microphones i and j is

$$\tau_{ij}(\mathbf{u})=-\frac{(\mathbf{r}_i-\mathbf{r}_j)^T\mathbf{u}}{c}.$$ (3)

The sign in (3) corresponds to a unit vector pointing from the array toward the source; a microphone closer to that source receives it earlier. The implementation and a known-direction self-check use the same convention. Channel ordering, yaw reference, sound speed and timing offsets must be verified before transferring the algorithm to another array.

A planar array cannot distinguish a source from its mirror below the plane using direct-path delays alone. Restricting the search to the upper hemisphere encodes prior information and resolves that ambiguity only for the stated task. Elevation also becomes poorly conditioned near the array plane because the derivative of the horizontal direction components with respect to elevation approaches zero. Near the zenith, azimuth becomes poorly defined even when the full three-dimensional direction is accurate. These are geometric limitations, rather than errors that can always be removed by spectral weighting.

The pipeline produces a frame-level target decision, a raw direction estimate, a directional score map and, for a sequence, a causal filtered direction with an explicit validity flag. It does not estimate range from a single far-field array. Detection, localization conditional on detection, localization over all target-present frames and tracking availability are distinct outputs. Reporting them separately prevents a low mean angular error obtained by rejecting difficult frames from being mistaken for complete detection performance.

## IV Processing Method

### A Common spectral front end

Each decision uses a nonoverlapping 0.2 s block of eight-channel audio at 8 kHz. The channel means are removed. Five 512-sample periodic Hann windows, separated by 256 samples, provide short-time Fourier transform (STFT) snapshots. Let X_m(l,k) denote a microphone coefficient at snapshot l and frequency bin k. The time-averaged cross-spectrum and channel powers are

$$G_{ij}(k)=\frac{1}{L}\sum_{l=1}^{L}X_i(l,k)X_j^*(l,k),\quad L=5.$$ (4)

$$P_m(k)=\frac{1}{L}\sum_{l=1}^{L}|X_m(l,k)|^2.$$ (5)

The PHAT spectrum and magnitude-squared coherence estimate are

$$Q_{ij}(k)=\frac{G_{ij}(k)}{\max(|G_{ij}(k)|,\epsilon)}.$$ (6)

$$\gamma_{ij}(k)=\min\left(1,\frac{|G_{ij}(k)|^2}{P_i(k)P_j(k)+\epsilon}\right).$$ (7)

The implementation uses epsilon = 10 to the power of -20. Only bins from 200 to 3000 Hz contribute to spatial search. The 200 Hz lower limit attenuates part of the wind-like spectrum in the experiment; it is a declared processing parameter, not a universal boundary between wind and UAV sound. Coherence estimated from only five snapshots has finite-sample bias and variance. It should be interpreted as a short-block reliability cue, not an unbiased probability of target presence.

### B Estimated harmonic support

A separate 2048-point transform of the complete Hann-windowed block gives the mean power S(k) across microphones. The algorithm divides it by a 31-bin running median F(k), takes log(1 + S/F) minus log(2), and applies a Gaussian smoothing filter with standard deviation one frequency bin. Denote the resulting spectral contrast by z(k). Candidate fundamentals are searched from 80 to 240 Hz in 2 Hz increments. For each candidate, the algorithm samples the nearest transform bin at each of twelve harmonics and computes

$$H(f_0)=\frac{\sum_{h=1}^{12}h^{-1/2}z(\mathrm{round}(h f_0 N_F/f_s))}{\sum_{h=1}^{12}h^{-1/2}}.$$ (8)

The estimate f-hat is the maximizing candidate. The known simulation fundamental is stored only for analysis and is never passed to the estimator. This search can select a subharmonic or an interfering engine fundamental; the method contains no oracle step that identifies which periodic source is the UAV.

For frequency f_k, define the distance to the nearest integer multiple of the estimated fundamental and a soft harmonic weight as

$$d_k=|f_k-\mathrm{round}(f_k/\hat f_0)\hat f_0|.$$ (9)

$$b_k=0.1+0.9\exp\left[-\frac{d_k^2}{2\max(8,0.012f_k)^2}\right].$$ (10)

The 0.1 floor retains some broadband evidence. The increasing bandwidth accommodates harmonic broadening without claiming to estimate each rotor's speed. The baseline and every ablation receive the same microphone data, candidate grid and STFT implementation.

### C Four spatial estimators

Let B_k equal one within the processing band and zero elsewhere. The four tested weights are B_k for PHAT, B_k(0.05 + 0.95 gamma_ij) for coherence weighting, B_k b_k for harmonic weighting, and

$$w_{ij}^{HC}(k)=B_k b_k\,[0.05+0.95\gamma_{ij}(k)]$$ (11)

for combined harmonic-coherence weighting. Each weighted PHAT spectrum is transformed into a correlation function with an inverse real FFT of length 4096, giving eightfold delay-grid oversampling. Linear interpolation evaluates that function at the delay predicted by (3). With r_ij denoting the interpolated correlation, the score map is

$$R(\mathbf{u})=\sum_{i<j}r_{ij}(\tau_{ij}(\mathbf{u})),\qquad\hat{\mathbf{u}}=\arg\max_{\mathbf{u}\in\mathcal{G}}R(\mathbf{u}).$$ (12)

The grid contains azimuths 0, 3, ..., 357 degrees and elevations 0, 3, ..., 87 degrees, plus one zenith point, for 3601 candidates. All 28 microphone pairs are used. Candidate delay indices and interpolation factors are precomputed. The map maximum gives the raw azimuth and elevation; it is a directional image peak rather than a Cartesian position or range estimate. Spectral masking and weighting are established techniques [4, 10]; the ablation isolates their behavior in this particular implementation.

### D Shared detection rule and validation threshold

The frame detector combines the nonnegative best harmonic contrast with the coherence averaged over harmonic-weighted microphone pairs and frequencies. Let gamma-bar-H denote that average. Its score is

$$D=\max(0,H(\hat f_0))\,[0.25+\bar\gamma_H].$$ (13)

The same detector gates all four spatial methods. Thus localization ablations do not imply different detection operating points. The threshold uses only independent target-absent validation frames. Given n such scores and nominal false-alarm level alpha = 0.05, the selected one-based order statistic is

$$q=\left\lceil(n+1)(1-\alpha)\right\rceil,\qquad T=D_{(q)}.$$ (14)

A frame is detected if and only if D is strictly greater than T. This calibration chooses a conservative empirical operating point without maximizing test accuracy. It does not guarantee a 5% false-alarm rate under another noise mixture, at another location, or for every nuisance class separately. A ground engine is deliberately retained among negative examples because tonal coherence alone is not a semantic aircraft classifier.

### E Causal direction smoothing

The temporal estimator averages unit vectors and renormalizes, avoiding a discontinuity at the azimuth wrap. For an accepted observation at time t,

$$\mathbf{v}_t=\frac{0.65\mathbf{v}_{t-1}+0.35\hat{\mathbf{u}}_t}{\|0.65\mathbf{v}_{t-1}+0.35\hat{\mathbf{u}}_t\|_2}.$$ (15)

The first accepted observation initializes the state. The evaluation includes raw directions, smoothing of every frame, and detection-gated smoothing. The gated state is held for at most five missed frames and is then invalidated. A held state is not counted as a new detection. This simple causal smoother has no velocity model and may lag maneuvers; smoothing is therefore assessed by error and availability rather than appearance alone. At a 0.2 s hop, the one-second hold policy can preserve a displayed direction despite interrupted acoustic evidence. Detection continuity and output continuity are consequently evaluated separately.

### F Computational requirements

With M microphones, P = M(M - 1)/2 pairs, K spectral bins, correlation length N_C and G candidate directions, the principal work per spatial estimator is of order P N_C log(N_C) + P G, after the spectral front end. The delay lookup uses storage proportional to P G. Here P = 28, N_C = 4096 and G = 3601. This avoids storing a dense complex tensor over all pairs, frequencies and directions. The implementation deliberately retains a regular exhaustive grid: replacing it with coarse-to-fine or learned search is unnecessary for testing the weighting hypothesis and would change the ablation.

## V Experimental Protocol

### A Generated data and propagation

The simulated array has eight nonuniform planar microphones and an aperture of approximately 0.40 m; its exact coordinates are saved in the experiment configuration. Static target azimuth is uniform over a complete turn, and the sine of elevation is uniform from zero to one, producing uniform directional area over the upper hemisphere. Geometric source distance is drawn from 20 to 80 m. After propagation, target and nuisance amplitudes are normalized to impose SNR, so these distances control wavefront curvature only. Performance is therefore evaluated as a function of SNR rather than physical detection range.

The target generator sums four rotor-like harmonic series with a shared base frequency drawn uniformly from 85 to 230 Hz, independent rotor offsets, slowly varying instantaneous frequency, random harmonic amplitudes and phase, and a band-limited stochastic component. Up to fifteen harmonics below approximately 3.2 kHz are included. The nominal tonal mixing fraction ranges from 0.55 to 0.85. This analytic generator captures selected spectral mechanisms; it does not reproduce a specified commercial aircraft's measured sound signature or radiation directivity.

Waveforms are synthesized at 24 kHz and sampled after time-domain interpolation of spherical propagation delays. The estimator instead uses nominal far-field delays. Actual sound speed varies uniformly from 338 to 348 m/s, whereas steering assumes 343 m/s. Channel gain variation has a standard deviation of 0.6 dB. Target-present mixtures include a delayed, redirected echo with relative amplitude from 0.05 to 0.25 and delay from 3 to 12 ms. This is an artificial echo perturbation, not a validated outdoor ground-reflection model. These differences reduce exact forward/inverse identity, but do not remove the shared assumptions between simulation and estimator.

Four equally represented nuisance families are used: independent sensor noise; wind-like low-pass noise with a weaker shared low-frequency component; a coherent directional broadband interferer plus sensor noise; and a directional, highly tonal engine-like interferer plus sensor noise. Engine-like sound uses one harmonic series and a nominal tonal fraction of 0.82–0.95. Its fundamental lies in the same range as the target's, making it an intentionally difficult negative. None of these generated nuisances is labelled as a measured recording of wind or an engine.

The imposed SNR is the energy ratio of the direct target component to the complete nuisance mixture, averaged over microphones and samples before adding the target echo. It is a full-band quantity; filtering changes the effective in-band SNR, particularly for wind-like noise. For stationary trials it takes values -15, -10, -5, 0 and 5 dB. Measured component-energy SNR is retained with every generated item.

### B Splits and controlled comparisons

Table I summarizes independent evaluation units. The master random seed is 20261002, with separate seed namespaces for threshold validation, test negatives, test positives, sensor sensitivity and tracking. No labels, true fundamental or true bearing enter the estimator. All reported results use the complete experimental partitions. Thresholds and method constants are fixed before test evaluation.

Table I. Dataset partitions and independent units. Each stationary audio item contains eight channels and 1600 samples per channel.

| Partition | Units | Purpose |
|---|---|---|
| Validation | 800 absent frames | 200 per nuisance; set one threshold |
| Static test | 1000 present + 1000 absent | 50 present per scene/SNR; 250 absent per scene |
| Sensor sensitivity | 120 paired source draws, four conditions | Nominal, 5 mm position error, 20 microsecond delay error, both |
| Dynamic test | 24 sequences, 24 s each | Four scenes, three SNRs, two sequences per cell |

Sensor perturbations use independent zero-mean Gaussian offsets per coordinate or channel, with standard deviations of 5 mm and 20 microseconds. The same source/noise draws are reused across the four sensitivity conditions. Nominal array coordinates are used by the estimator in every condition. This paired design isolates the perturbation under the model, rather than confounding it with different sound draws.

Continuous sequences use a single waveform, nuisance realization and channel configuration throughout. The target is absent in the first and last 2 s and present in between; its level varies by plus or minus 3 dB. Azimuth moves at a signed rate of 6–18 degrees/s, reversing at half the sequence duration to -0.7 times the initial rate. Elevation follows a sinusoid between 15 and 65 degrees. These are angular-maneuver stress sequences, not validated low-speed flight trajectories: the largest radius/rate combinations imply substantial speed, and the turn has no acceleration constraint. The reference direction is sampled at each frame center. Subframe motion is therefore retained while the estimator assumes one direction per frame.

### C Metrics and uncertainty

Detection recall is TP divided by all target-present items; false-alarm rate (FPR) is FP divided by all target-absent items. Balanced accuracy is (recall + 1 - FPR)/2. SNR-specific recall is evaluated on its positive subset, while all such rows share the same negative test set.

The principal localization error is the angle between the estimated and reference unit vectors:

$$e=\operatorname{atan2}(\|\hat{\mathbf{u}}\times\mathbf{u}\|_2,\hat{\mathbf{u}}^T\mathbf{u}).$$ (16)

Angles are converted to degrees. Signed azimuth error is wrapped to [-180, 180), and elevation error is the ordinary difference. The outputs include mean, median, tail errors, coordinate errors, and the fraction within 10 degrees. Unconditional errors include every target-present item. Detected-only errors are accompanied by their smaller denominator. Joint success requires both a detection and angular error no greater than 10 degrees, divided by all positive items; rejected items remain failures for that metric.

For static errors, 2000 bootstrap replicates resample independent trials within scene/SNR strata. For method comparisons, the PHAT error minus alternative-method error is computed for each identical trial before resampling; positive differences indicate improvement. Detection-rate intervals are Wilson intervals, and balanced-accuracy uncertainty uses independent positive/negative stratified resampling. These intervals are conditional on the frozen threshold and generator, rather than uncertainty across real aircraft and environments. Multiple comparisons are descriptive, without a multiplicity adjustment.

Tracking metrics are first calculated within each complete sequence and then averaged with equal sequence weight. Bootstrap units are complete sequences, never adjacent frames or overlapping windows. Gated conditional errors omit sequences with no output only from their conditional-error average; the number of sequences with output and coverage remain explicit. Tracking tail values are the mean of sequence-specific 95th percentiles, not one pooled percentile. A separate illustrative continuity metric counts five-second positive windows with at least 80% detections and no detection gap over 0.5 s. Held states cannot satisfy this detection rule on their own, and overlapping windows are not treated as independent statistical samples.

### D Runtime and a real-recording inspection

The timing measurement uses a Windows workstation with an Intel Core i7-12700KF processor and single-thread numerical-library settings. It includes the shared spectral front end plus one spatial search, excluding source synthesis, file I/O, visualization, initialization and warm-up. The same shared front end is charged to all methods; a dedicated PHAT-only implementation could avoid unused feature calculations. The 0.2 s acquisition window and any physical propagation delay are excluded from this compute timing and must be added when assessing operational latency. The output update rate remains 5 Hz, regardless of the higher achievable compute throughput.

One unmodified 30 s, eight-channel, 48 kHz recording from the Fraunhofer IDMT dataset is also archived under its CC BY 4.0 license [19, 10]. Figure 1 shows a descriptive spectrogram of its first recorded channel. The analysis uses 4096-sample Tukey windows with 3072-sample overlap; displayed power is relative to the maximum in the shown band. This recording is not used to tune the method or calculate the performance tables. The upstream documentation provides azimuth but no valid elevation labels; placeholder elevation fields must not be interpreted as three-dimensional ground truth. A single inspected clip cannot validate target identity, range or the proposed detector's false-alarm rate.

![Figure 1. First-channel spectrogram of the licensed real IDMT sample, shown only for signal inspection. Time-varying tonal bands coexist with broadband energy; no detection or localization accuracy is inferred from this plot.](../figures/public_audio_spectrogram.png)

## VI Results

### A Overall localization and paired effects

Table II reports unconditional localization on all 1000 positive test items. Standard PHAT has the lowest mean error in this mixture. The combined method has a small median error, but also a large upper tail; reporting only the median would hide frequent wrong-source estimates. The paired PHAT-minus-combined difference is -1.71 degrees, with a 95% bootstrap interval of [-2.68, -0.72] degrees. Thus these observations do not support an overall improvement from multiplying the two weights. Harmonic-only weighting also worsens the overall mean by 1.38 degrees, while the coherence-only paired interval spans zero.

Table II. Unconditional static localization. C denotes coherence, H harmonic weighting and HC their combination. The last column is the percentage of all positive items with angular error at most 10 degrees.

| Method | Mean (deg) | Median (deg) | P95 (deg) | Within 10 (%) |
|---|---|---|---|---|
| PHAT | 24.84 | 2.77 | 114.26 | 66.4 |
| C | 25.12 | 2.94 | 110.99 | 66.3 |
| H | 26.22 | 3.08 | 114.18 | 64.5 |
| HC | 26.55 | 3.30 | 114.54 | 64.3 |

Figure 2 shows the dependence on SNR. At 5 dB, all four methods achieve mean errors close to two degrees. This favorable high-SNR localization result cannot establish detection success because the detector is a separate operation. At -5 dB, combined weighting worsens PHAT by 9.70 degrees on average, with a paired degradation interval of [6.93, 12.49] degrees. The nonmonotonic aggregate between -15 and -10 dB reflects different independent draws and competing-source selection; it should not be described as a physical law that lower SNR improves localization.

![Figure 2. Unconditional mean spherical error versus imposed mixture SNR, with 200 independent positive trials per SNR. The four methods use identical observations; the complete tail and paired-interval tables are retained in the supplementary results.](../figures/paper_localization.png)

### B Nuisance-dependent ranking

Table III explains why a single favorable example is insufficient. In directional broadband interference, HC reduces the mean from 54.50 to 51.80 degrees. The paired improvement is 2.70 degrees with interval [1.00, 4.58] degrees. This is a measurable conditional benefit, but the remaining absolute error is large. In the engine-like condition, HC increases error from 37.41 to 46.91 degrees, a degradation of 9.51 degrees with interval [6.79, 12.44] degrees. Its harmonic prior can favor the periodic interferer, and coherence does not identify which coherent source is the intended target.

Table III. Mean spherical error by nuisance, in degrees; each row contains 250 positive trials pooled equally across the five SNRs.

| Nuisance | PHAT | C | H | HC |
|---|---|---|---|---|
| Sensor | 5.54 | 4.46 | 5.70 | 5.50 |
| Wind-like | 1.92 | 1.91 | 1.96 | 2.00 |
| Directional | 54.50 | 54.51 | 52.86 | 51.80 |
| Engine-like | 37.41 | 39.61 | 44.36 | 46.91 |

The small wind-like errors reflect the declared low-frequency nuisance model and the fixed 200 Hz high-pass boundary. They do not establish robustness to actual wind buffeting, turbulent coherence, microphone saturation or high-frequency wind components. Coherence weighting improves the sensor-noise point estimate by 1.08 degrees, but its subgroup paired interval includes zero. These distinctions prevent positive-looking point estimates from being generalized beyond their evidence.

### C Shared detector failure

The validation threshold is 1.888012, selected as order statistic 761 of 800 negative scores. Its validation FPR is 4.875%. On the independent balanced test set there are 35 true detections and 56 false alarms, yielding recall 3.50% (Wilson 95% interval 2.53–4.83%), FPR 5.60% (4.34–7.20%) and balanced accuracy 48.95% (bootstrap interval 48.10–49.75%). The detector consequently rejects most target-present observations at this working point. All false alarms occur in the engine-like negative subset, whose FPR is 22.4%.

Table IV. Detection under the single frozen threshold. Each scene has 250 positive and 250 negative test items. AUC is a descriptive ranking measure computed on the held-out scores, not a threshold-selection procedure.

| Scene | Recall (%) | FPR (%) | AUC |
|---|---|---|---|
| Sensor | 0.0 | 0.0 | 0.995 |
| Wind-like | 2.4 | 0.0 | 0.994 |
| Directional | 1.6 | 0.0 | 0.947 |
| Engine-like | 10.0 | 22.4 | 0.314 |
| All scenes | 3.5 | 5.6 | 0.735 |

The receiver operating characteristic (ROC) in Figure 3 separates ranking information from the chosen working point. Near-perfect within-scene ranking for sensor and wind-like examples coexists with very low recall at the common threshold: the engine-like validation negatives force a high threshold. In the engine subgroup, an area under the curve (AUC) below 0.5 indicates that stronger target-presence scores often favor the negative engine-only mixtures. Adding a less purely tonal multirotor target can dilute the contrast statistic. Thus poor performance is not resolved by claiming that a lower threshold would be universally acceptable. A different threshold would need a new operating-point decision and independent validation.

![Figure 3. Test-score ROC curves for all scenes and engine-like interference, with the frozen global operating point marked. The curves describe this test set; no test-selected threshold is used in the reported detection or tracking results.](../figures/paper_roc.png)

For HC, the mean error among the 35 detected positive frames is 22.86 degrees. Although 24 of those frames fall within 10 degrees, their 68.57% conditional success fraction becomes only 2.40% when divided by all 1000 positive frames. This denominator difference is operationally decisive. At -5 dB no positive frame is detected, so detected-only error is undefined rather than zero. The accompanying machine-readable tables preserve missing quantities as null values.

### D Smoothing and gated availability

Across the 24 independent dynamic sequences, HC has a raw sequence-mean error of 26.76 degrees. Smoothing every frame raises it to 28.13 degrees. The paired raw-minus-smoothed interval is [-2.03, -0.75] degrees, supporting deterioration under these maneuver conditions. Nevertheless, the mean within-sequence root-mean-square directional step decreases from 7.31 to 3.02 degrees. A smoother-looking trajectory can therefore be less accurate because of lag and persistence of an incorrectly selected source. The PHAT, coherence and harmonic variants show the same direction of change in their overall mean errors.

Table V. Dynamic results for HC. Coverage uses every positive frame. The gated conditional mean is calculated from only six sequences with available positive-period output and is not directly comparable to full-coverage means.

| Output | Mean error (deg) | Coverage (%) | Sequences with output |
|---|---|---|---|
| Raw | 26.76 | 100.000 | 24/24 |
| Smooth all | 28.13 | 100.000 | 24/24 |
| Gated | 65.54 | 5.625 | 6/24 |

The detector recognizes positive frames in only five of 24 sequences. Gated output exists in six because a state initialized by an earlier false alarm can persist into a positive interval. Its mean positive-period coverage is 5.625%, while 4.667% of positive frames have only stale held output. The sequence-averaged dynamic detection recall is 0.958%, the absent-period detector FPR is 8.750%, and gated output is still present during 19.583% of absent frames. The illustrative five-second detection-continuity pass rate is zero. These results cannot support a claim of continuous target tracking, regardless of how stable a held marker appears.

### E Calibration sensitivity and compute time

Table VI shows the combined method's paired sensor-perturbation experiment. Separate position and timing errors increase mean error, but the joint condition is not additive and its paired interval includes zero. An argmax can switch between target and interferer, so worsening the physical calibration need not increase every trial's target error monotonically. The nominal sensitivity subset is distinct from the main test set and uses only -10, -5 and 0 dB; its mean should not be subtracted from the main test mean as if they were paired.

Table VI. HC sensitivity over 120 paired independent source draws. Delta is perturbed minus nominal mean error; brackets give the paired 95% interval, in degrees.

| Perturbation | Mean error (deg) | Delta and interval (deg) |
|---|---|---|
| Nominal | 33.14 | Reference |
| Position 5 mm | 33.77 | 0.63 [0.27, 1.00] |
| Delay 20 microseconds | 34.09 | 0.95 [0.40, 1.50] |
| Both | 33.94 | 0.80 [-0.47, 1.77] |

For HC, the measured median, mean and 95th-percentile front-end-plus-search times are 3.11, 3.29 and 4.67 ms. The PHAT mean is 3.56 ms in the shared implementation. Their small difference does not establish an algorithmic speed advantage: execution order, caching and host load were not controlled as a dedicated performance study. The measured compute cost leaves substantial headroom within a 200 ms frame period on this workstation. Adding the acquisition block to the HC 95th-percentile compute time gives approximately 204.67 ms before other system delays. The experiment supports this narrow workstation feasibility statement, not a claim that the complete device meets its operational requirements.

## VII Discussion and Deployment Implications

The main practical finding is that localization reliability, periodic-source detection and aircraft identification are different problems. A soft harmonic weight can help when the nuisance is spectrally dissimilar, yet strengthen an engine-like distractor. Pairwise coherence rewards consistency across sensors, not the intended object's identity. Multiplying the cues does not make them independent or guarantee that their errors cancel. The mixed-condition evaluation exposes this failure more clearly than a white-noise-only localization test.

The result suggests a deployment decision: retain plain PHAT as the reference estimator for this declared mixture, and do not install the tested shared detector as a reliable UAV alarm. A candidate detector should be redesigned using evidence that separates target and confounder classes, such as multi-rotor modulation structure, temporal spectral evolution or a classifier trained on labelled field negatives. Such extensions are future hypotheses, not improvements demonstrated in this experiment. A motion-aware tracker may reduce maneuver lag, but it cannot repair a gate that almost never accepts the target or persistently selects another source.

The study has several limits. The generator covers one family of analytic rotor-like signals, four artificial nuisance families and a simple redirected echo. It omits measured microphone transfer functions, microphone wind nonlinearities, full diffuse-field statistics, frequency-dependent ground reflection, atmospheric absorption, calibrated radiation levels, absolute emission-to-reception delay, and a validated Doppler/flight-dynamics model. The small planar geometry also produces intrinsic elevation conditioning and spatial ambiguity. Shared modeling assumptions may favor the analytic estimators even though source interpolation, propagation geometry and sound speed differ from steering. Consequently, neither positive nor negative numerical effect sizes should be transferred unchanged to an actual airfield or device.

The real recording provides an example of time-varying tonal structure, but does not close this external-validity gap. A subsequent field evaluation should use independent flight/session splits, a verified array coordinate transformation, calibrated channel delays, pure-background recordings and difficult mechanical negatives. The entire detection/localization/tracking chain should then be measured at specified physical distances. Continuity should be computed from actual detections rather than display persistence, and device timing should include acquisition, buffering and output. These measurements would test whether the observed nuisance-dependent effects persist outside the generator distribution.

The supplementary materials preserve all validation, test and sensitivity mixtures as float32 multichannel archives, complete dynamic recordings, component metadata, seed tuples, exact environment versions and source hashes. Per-frame CSV files distinguish target label, detection, track validity and stale state. A fixed example also includes all 3601 acoustic-map responses and peak coordinates, supporting verification of both favorable and unfavorable results.

## VIII Conclusion

A reproducible eight-microphone study has evaluated harmonic and coherence weighting for acoustic UAV-related detection and direction estimation. Combined weighting gives a conditional benefit against directional broadband interference but degrades the full-mixture mean and the engine-like subgroup. A shared harmonic-coherence detector achieves only 3.50% recall at 5.60% false alarms, while simple causal smoothing trades reduced directional movement for increased tracking error. The evidence therefore rejects a general robustness claim for this combination under the tested conditions. The study provides a documented counterexample to assuming that complementary acoustic cues automatically yield a reliable UAV system, together with complete code and data for testing better discriminative and temporal methods. External validation with calibrated field recordings remains necessary to establish operational applicability.

## Data and Code Availability

The supplementary research package contains the simulation and analysis code, complete generated multichannel audio, per-frame estimates, experiment configuration, exact software versions and source hashes. The real audio sample is attributed to Yang and Bitzer [19] under CC BY 4.0; the original waveform and its provenance record are retained. The software README describes reproduction and the mapping between raw outcomes, summary tables and figures.

## References

[1] P. Chen, Y. Chen, and W. Wang, "Review for UAV Acoustic Positioning," Journal of South China University of Technology (Natural Science Edition), vol. 50, no. 12, pp. 109-123 (in Chinese), 2022. [doi: 10.12141/j.issn.1000-565X.220277](https://doi.org/10.12141/j.issn.1000-565X.220277).

[2] Charles H. Knapp, G. Clifford Carter, "The generalized correlation method for estimation of time delay," IEEE Transactions on Acoustics, Speech, and Signal Processing, 24(4), 320–327, 1976. [doi: 10.1109/TASSP.1976.1162830](https://doi.org/10.1109/TASSP.1976.1162830).

[3] Joseph H. DiBiase, Harvey F. Silverman, Michael S. Brandstein, "Robust Localization in Reverberant Rooms," In Michael Brandstein and Darren Ward (eds.), Microphone Arrays: Signal Processing Techniques and Applications, Digital Signal Processing, Springer, Berlin, Heidelberg, Chapter 8, pp. 157–180, 2001. [doi: 10.1007/978-3-662-04619-7_8](https://doi.org/10.1007/978-3-662-04619-7_8).

[4] Eric Grinstein et al., "Steered Response Power for Sound Source Localization: a tutorial review," EURASIP Journal on Audio, Speech, and Music Processing, 2024, article 59, 2024. [doi: 10.1186/s13636-024-00377-z](https://doi.org/10.1186/s13636-024-00377-z).

[5] Ralph O. Schmidt, "Multiple emitter location and signal parameter estimation," IEEE Transactions on Antennas and Propagation, 34(3), 276–280, 1986. [doi: 10.1109/TAP.1986.1143830](https://doi.org/10.1109/TAP.1986.1143830).

[6] Kevin D. Donohue, Jens Hannemann, Henry G. Dietz, "Performance of phase transform for detecting sound sources with microphone arrays in reverberant and noisy environments," Signal Processing, 87(7), 1677–1691, 2007. [doi: 10.1016/j.sigpro.2007.01.013](https://doi.org/10.1016/j.sigpro.2007.01.013).

[7] Jean-Marc Valin, François Michaud, Jean Rouat, "Robust localization and tracking of simultaneous moving sound sources using beamforming and particle filtering," Robotics and Autonomous Systems, 55(3), 216–228, 2007. [doi: 10.1016/j.robot.2006.08.004](https://doi.org/10.1016/j.robot.2006.08.004).

[8] Klaus Brümann, Simon Doclo, "Steered Response Power-Based Direction-of-Arrival Estimation Exploiting an Auxiliary Microphone," 2024 32nd European Signal Processing Conference (EUSIPCO), 917–921, 2024. [doi: 10.23919/EUSIPCO63174.2024.10715232](https://doi.org/10.23919/EUSIPCO63174.2024.10715232).

[9] Kurt Heutschi, Beat Ott, Thomas Nussbaumer, Peter Wellig, "Synthesis of real world drone signals based on lab recordings," Acta Acustica, 4, article 24, 2020. [doi: 10.1051/aacus/2020023](https://doi.org/10.1051/aacus/2020023).

[10] Ximei Yang, Patrick A. Naylor, Simon Doclo, Joerg Bitzer, "Neural Drone Localization Exploiting Signal Synthesis of Real-World Audio Data," 2025 33rd European Signal Processing Conference (EUSIPCO), 256–260, 2025. [doi: 10.23919/EUSIPCO63237.2025.11226465](https://doi.org/10.23919/EUSIPCO63237.2025.11226465).

[11] Pierre-Amaury Grumiaux, Srđan Kitić, Laurent Girin, Alexandre Guérin, "A survey of sound source localization with deep learning methods," The Journal of the Acoustical Society of America, 152(1), 107–151, 2022. [doi: 10.1121/10.0011809](https://doi.org/10.1121/10.0011809).

[12] Seçkin Uluskan, "Precise acoustic drone localization and tracking via drone noise: Steered response power - phase transform around harmonics," International Journal of Aeroacoustics, 23(5–6), 558–577, 2024. [doi: 10.1177/1475472X241259082](https://doi.org/10.1177/1475472X241259082).

[13] Saeid Safavi et al., "DDL: A Dataset for Drone Detection and Localization From Multi-Channel Audio and a Deep Uncertainty-Aware Framework," 2025 IEEE 35th International Workshop on Machine Learning for Signal Processing (MLSP), 1–6, 2025. [doi: 10.1109/MLSP62443.2025.11204285](https://doi.org/10.1109/MLSP62443.2025.11204285).

[14] Belman Jahir Rodríguez et al., "Acoustic Imaging for UAV Detection: Dense Beamformed Energy Maps and U-Net SELD," arXiv preprint arXiv:2508.00307, 2025. [doi: 10.48550/arXiv.2508.00307](https://doi.org/10.48550/arXiv.2508.00307).

[15] Gabriel Jekateryńczuk, Rafał Szadkowski, Zbigniew Piotrowski, "UaVirBASE: A Public-Access Unmanned Aerial Vehicle Sound Source Localization Dataset," Applied Sciences, 15(10), article 5378, 2025. [doi: 10.3390/app15105378](https://doi.org/10.3390/app15105378).

[16] Belman Jahir Rodriguez, Sergio Chevtchenko, Saeed Afshar, "UAV Acoustic Localization Dataset: 24-Channel Beamformed Recordings of a DJI Air 3 Drone with Synchronized GPS Flight Logs," Western Sydney University (dataset), 2026. [doi: 10.26183/07nm-4p35](https://doi.org/10.26183/07nm-4p35).

[17] Martin Strauß, Pol Mordel, Victor Miguet, Antoine Deleforge, "DREGON: Dataset and Methods for UAV-Embedded Sound Source Localization," 2018 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS), 5735–5742, 2018. [doi: 10.1109/IROS.2018.8593581](https://doi.org/10.1109/IROS.2018.8593581).

[18] Chitralekha Gupta et al., "DroneAudioset: An Audio Dataset for Drone-based Search and Rescue," Advances in Neural Information Processing Systems, 38, Datasets and Benchmarks Track, 2025. [Publisher record](https://proceedings.neurips.cc/paper_files/paper/2025/hash/adececbc73a58724db0f3c0d5c77f338-Abstract-Datasets_and_Benchmarks_Track.html).

[19] Ximei Yang, Joerg Bitzer, "Real-World Drone Audio Dataset Collected by Fraunhofer IDMT (August 2022)," Fraunhofer IDMT via Zenodo (dataset), 2025. [doi: 10.5281/zenodo.17525811](https://doi.org/10.5281/zenodo.17525811).
